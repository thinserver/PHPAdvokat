filename=$1
dirname=$2

cd $dirname
/usr/bin/pdflatex $filename
