insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  110 , 'Konzessionen                                      ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  135 , 'EDV Software                                      ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  150 , 'Gesch�fts- oder Firmenwert                        ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  200 , 'Grundst�cke, Geb�ude                              ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  250 , 'Fabrikbauten                                      ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  260 , 'Andere Bauten                                     ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  440 , 'Maschinen                                         ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  500 , 'Betriebs- u. Gesch�ftsausstattung                 ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  520 , 'Pkw                                               ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  540 , 'Lkw                                               ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  620 , 'Werkzeuge                                         ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  640 , 'Ladeneinrichtung                                  ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  650 , 'B�roeinrichtungen                                 ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  670 , 'GWG bis 410 Euro                                  ',      0 ,  1406 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1370 , 'Durchlaufende Posten                              ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1374 , 'Fremdgeld                                         ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1400 , 'Abziehbare Vorsteuer                              ',     66 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1401 , 'Abziehbare Vorsteuer  7%                          ',     66 ,     0 , '    7', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1402 , 'Abziehbare Vorsteuer  7%  innergem. Erwerb        ',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1403 , 'Abziehbare Vorsteuer 16%  innergem. Erwerb        ',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1404 , 'Abziehbare Vorsteuer 19%  innergem. Erwerb        ',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1405 , 'Abziehbare Vorsteuer 16%                          ',     66 ,     0 , '   16', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1406 , 'Abziehbare Vorsteuer 19%                          ',     66 ,     0 , '   19', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1407 , 'Abziehbare Vorsteuer nach � 13b UStG 19%          ',     67 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1408 , 'Anrechenbare Vorsteuer nach � 13b UStG            ',     67 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1409 , 'Anrechenbare Vorsteuer nach � 13b UStG 16%        ',     67 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1418 , 'Vorsteuer gem. �13b UStG 16%                      ',     67 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1433 , 'Bezahlte Einfuhr-Umsatzsteuer                     ',     62 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1460 , 'Geldtransit                                       ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1490 , 'Verrechnungskonto Ist-Versteuerung                ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1550 , 'Schecks                                           ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1600 , 'Kasse                                             ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1700 , 'Postbank                                          ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1800 , 'Bank                                              ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2100 , 'Privatentnahmen                                   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2130 , 'Privatverbrauch                                   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2150 , 'Privatsteuern                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2180 , 'Privateinlagen                                    ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2250 , 'Spenden, Zuwendungen                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2990 , 'Sonderabschreibungen                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3800 , 'Umsatzsteuer                                      ',     36 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3801 , 'Umsatzsteuer 7%                                   ',      0 ,     0 , '    7', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3802 , 'Umsatzsteuer  7% a. innergem. Erwerb              ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3803 , 'Umsatzsteuer 16% a. innergem. Erwerb              ',     98 ,     0 , '   16', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3804 , 'Umsatzsteuer 19% a. innergem. Erwerb              ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3805 , 'Umsatzsteuer 16 %                                 ',     36 ,     0 , '   16', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3806 , 'Umsatzsteuer 19 %                                 ',      0 ,     0 , '   19', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3808 , 'Umsatzsteuer a.i.Inland steuerpfl.EG-Lief. 19%    ',     81 ,     0 , '   19', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3820 , 'Umsatzsteuer-Vorauszahlungen                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3830 , 'Umsatzsteuer-Vorauszahlungen 1/11                 ',     39 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3832 , 'Umsatzsteuer-Erstattungen                         ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3833 , 'Umsatzst. n.�13b Abs.2 UStG 16%                   ',     53 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3835 , 'Umsatzsteuer � 13b UStG                           ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3836 , 'Umsatzsteuer � 13b UStG 16%                       ',     85 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3837 , 'Umsatzsteuer � 13b UStG 19%                       ',     85 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3841 , 'Umsatzsteuer Vorjahr                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4000 , 'Umsatzerl�se                                      ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4100 , 'Steuerfreie Ums�tze � 4 Nr. 8 ff UStG             ',     48 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4120 , 'Steuerfreie Ums�tze � 4 Nr. 2 ff UStG             ',     43 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4125 , 'Steuerfreie Ums�tze innergem. Lieferungen         ',     41 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4150 , 'Sonstige steuerfreie Ums�tze                      ',     43 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4180 , 'Erl�se gem. � 24 UStG                             ',     76 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4185 , 'Erl�se gem. � 19 UStG                             ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4200 , 'Erl�se                                            ',     45 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4300 , 'Erl�se  7% USt                                    ',     86 ,  3801 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4310 , 'Erl�se a.i.Inl.stpfl.Lieferungen EU-Lfg.  7% USt  ',     86 ,  3801 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4315 , 'Erl�se a.i.Inl.stpfl.Lieferungen EU-Lfg.  19% USt ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4320 , 'Erl�se a.i.and.EG-Land steuerpfl.Lieferungen      ',     48 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4337 , 'Erl�se gem. �13b UStG 16% Ust.                    ',     60 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4400 , 'Erl�se 19% USt                                    ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4500 , 'Provisionserl�se                                  ',     35 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4506 , 'Provisionserl�se 7% USt                           ',     86 ,  3801 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4508 , 'Provisionserl�se 19% USt                          ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4610 , 'Warenentnahme 7% USt.                             ',     86 ,  3801 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4620 , 'Warenentnahme 19% USt.                            ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4630 , 'Verwendg.v.Gegenst. 7% USt                        ',     86 ,  3801 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4639 , 'Private Kfz-Nutzung ohne USt                      ',     48 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4645 , 'Private Kfz-Nutzung 19% USt                       ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4646 , 'Private Telefonnutzung 19% USt                    ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4845 , 'Erl�se Anlagenverkauf 19%                         ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4930 , 'Ertr�ge  a. Aufl�sung v. R�ckstellungen           ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4934 , 'Ertr�ge a.Aufl�sung v.SoPo m.R�ckl.Ant.(Existenzg)',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4936 , 'Ertr�ge a.Aufl�sung v.SoPo mit R�ckl.Ant(.Anspar) ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4970 , 'Versicherungsentsch�digungen                      ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5000 , 'Aufwend. f�r Roh-, Hilfs- und Betriebsstoffe      ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5100 , 'Einkauf Roh- Hilfs- u. Betriebsstoffe             ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5200 , 'Wareneingang                                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5300 , 'Wareneingang  7% VSt.                             ',      0 ,  1401 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5340 , 'Wareneingang 16% VSt.                             ',      0 ,  1405 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5400 , 'Wareneingang 19% VSt.                             ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5420 , 'Innergem. Erwerb  7% VSt/Ust                      ',     93 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5425 , 'Innergem. Erwerb 19% VSt/Ust                      ',     89 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5430 , 'Innergem. Erwerb ohne VSt-Abzug u. 7% USt         ',     93 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5433 , 'Innergem. Erwerb 16% VSt/Ust                      ',     95 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5435 , 'Innergem. Erwerb, ohne VSt-Abzug u. 19% USt.      ',     89 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5440 , 'IG.Erwerb v.Neu-KFZ v.Lief.ohne Ust-ID 19% VSt/Ust',     94 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5550 , 'Steuerfreier innergem. Erwerb                     ',     91 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5900 , 'Fremdleistungen                                   ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5910 , 'Bauleistungen e.i.Inland ans.UN  7% VSt./USt.     ',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5915 , 'Leistung.n.�13b UStG e.i.Ausland ans.UN 7% VSt/USt',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5920 , 'Bauleistungen e.i.Inland ans.UN  19% VSt./USt.    ',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5925 , ' .n.�13bUStG e.i.Ausland ans.UN 19% VSt/USt',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5930 , 'Bauleistungen e.i.Inland ans.UN o.VSt.Abzug 7% Ust',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5935 , 'Leistung.n.�13b UStG e.i.Ausl.ans.UN o.VSt/7%Ust  ',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5940 , 'Bauleistung.e.i.Inland ans.UN o. VSt.Abzug 19% Ust',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 5945 , 'Leistung.n.�13b UStG e.i.Ausl.ans.UN o.VSt/19%Ust ',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6000 , 'L�hne u. Geh�lter                                 ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6010 , 'L�hne                                             ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6020 , 'Geh�lter                                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6030 , 'Aushilfsl�hne                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6040 , 'Pauschale Steuer f�r Aushilfen                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6045 , 'Bedienungsgelder                                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6050 , 'Ehegattengehalt                                   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6060 , 'Freiwillige soz. Aufwendungen - LSt.pfl.          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6069 , 'Pauschale Steuer sonst. Bez�ge                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6070 , 'Krankengeldzusch�sse                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6110 , 'Gesetzliche soziale Aufwendungen                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6120 , 'Beitr�ge zur Berufsgenossenschaft                 ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6140 , 'Aufwendungen f�r Altersversorgung                 ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6170 , 'Sonstige soziale Abgaben                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6200 , 'Abschreibung  immaterielle Verm�gensgegenst�nde   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6205 , 'Abschreibungen Gesch�fts- od. Firmenwert          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6210 , 'Au�erpl. Abschreibungen auf immaterielle Verm�gens',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6220 , 'Abschreibungen auf Sachanlagen                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6221 , 'Abschreibungen auf Geb�ude                        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6222 , 'Abschreibungen auf KFZ                            ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6240 , 'Sonderabschreibungen Sachanlagen                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6241 , 'Sond. Abschreib.nach � 7g Abs.1 u.2 EStG(ohne Kfz)',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6242 , 'Sond. Abschreib.nach � 7g Abs.1 u.2 EStG(f�r Kfz) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6260 , 'Sofortabschreibung GWG                            ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6262 , 'Abschreibung aktivierte GWG                       ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6266 , 'Au�erplanm. Abschreibung aktivierte GWG           ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6300 , 'Sonst. betriebl. Aufwendungen                     ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6305 , 'Raumkosten                                        ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6310 , 'Miete                                             ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6315 , 'Pacht                                             ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6320 , 'Heizung                                           ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6325 , 'Gas, Strom, Wasser                                ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6330 , 'Reinigung                                         ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6335 , 'Instandhaltung betrieblicher R�ume                ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6340 , 'Abgaben f�r betrieblich genutzten Grundbesitz     ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6345 , 'Sonstige Raumkosten                               ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6348 , 'Aufw.f. h�usl.Arbeitszimmer (abzugsf�higer Anteil)',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6349 , 'Aufw.f. h�usl.Arbeitszimmer (nicht abzugsf�hig)   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6400 , 'Versicherungen                                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6430 , 'Sonstige Abgaben                                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6450 , 'Reparaturen und Instandhaltung von Bauten         ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6460 , 'Reparatur und Instandhaltung Maschinen            ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6470 , 'Reparatur und Instandh.Betr.u.Gesch�ftsaust.      ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6485 , 'Reparatur und Instandh. andere Anlagen            ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6490 , 'Sonstige Reparaturen, Instandhaltungen            ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6495 , 'Wartungskosten f. Hard- und Software              ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6500 , 'Kfz-Kosten                                        ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6520 , 'Kfz-Versicherungen                                ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6530 , 'Laufende Kfz-Betriebskosten                       ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6540 , 'Kfz-Reparaturen                                   ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6550 , 'Garagenmieten                                     ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6560 , 'Fremdfahrzeugkosten                               ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6570 , 'Sonst. Kfz-Kosten                                 ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6580 , 'Mautgeb�hren                                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6600 , 'Werbekosten                                       ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6610 , 'Geschenke (abzugsf�hig)                           ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6620 , 'Geschenke (nicht abzugsf�hig)                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6625 , 'Geschenke ausschl. betrieblich genutzt            ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6630 , 'Repr�sentationskosten (abziehb.)                  ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6640 , 'Bewirtungskosten (abzugsf�hig)                    ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6641 , 'Sonst.eingeschr�nkte Betriebsausgaben (abziehbar) ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6642 , 'Sonst.eingeschr�nkte Betriebsausgaben (nicht abz.)',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6644 , 'Nicht abzugsf�hige Bewirtungskosten               ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6645 , 'Nicht abzugsf�hige Betriebsausgaben               ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6650 , 'Reisekosten Arbeitnehmer                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6660 , 'Reisekosten AN �bernachtungsaufwand               ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6663 , 'Reisekosten AN Fahrtkosten                        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6664 , 'Reisekosten AN Verpflegungsmehraufwand            ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6668 , 'Kilometergelderstattung Arbeitnehmer              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6670 , 'Reisekosten Unternehmer                           ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6673 , 'Reisekosten UN Fahrtkosten                        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6674 , 'Reisekosten UN Verpflegungsmehraufwand            ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6680 , 'Reisekosten UN �bernachtungsaufwand               ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6688 , 'Fahrten zw. Wohnung und Arbeitsst�tte(abziehbar)  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6689 , 'Fahrten zw. Wohnung und Arbeitsst�tte(nicht abz.) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6700 , 'Kosten der Warenabgabe                            ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6710 , 'Verpackungsmaterial                               ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6740 , 'Ausgangsfrachten                                  ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6760 , 'Transportversicherungen                           ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6770 , 'Verkaufsprovision                                 ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6780 , 'Fremdarbeiten                                     ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6790 , 'Aufwendungen f�r Gew�hrleistungen                 ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6800 , 'Porto                                             ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6805 , 'Telefon                                           ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6810 , 'Telefax                                           ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6815 , 'B�robedarf                                        ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6820 , 'Zeitschriften, B�cher                             ',      0 ,  1401 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6821 , 'Fortbildungskosten                                ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6822 , 'Freiwillige Sozialleistungen                      ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6825 , 'Rechts- und Beratungskosten                       ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6827 , 'Abschlu�- und Pr�fungskosten                      ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6830 , 'Buchf�hrungskosten                                ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6835 , 'Mieten f�r Einrichtungen                          ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6840 , 'Mietleasing                                       ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6845 , 'Werkzeuge                                         ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6850 , 'Sonst. Betriebsbedarf                             ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6855 , 'Nebenkosten des Geldverkehrs                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6859 , 'Aufwend. f. Abraum- u. Abfallbeseitigung          ',      0 ,  1406 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6885 , 'Erl�se Anlagenverkauf 19%                         ',     81 ,  3806 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6889 , 'Erl�se Anlagenverkauf                             ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6925 , 'Einstellg.in SoPo mit R�cklageanteil(stfr.R�cklag)',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6926 , 'Einstellg.in SoPo mit R�cklageanteil(Ansparabsch) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 6928 , 'Einstellg.in SoPo mit R�cklageanteil(Existenzgr.) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7310 , 'Zinsaufwand f�r kurzfristige Verbindlichkeiten    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7313 , 'Nicht abzugsf�hig.Schuldzinsen langfr.�4Abs4a EStG',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7314 , 'Nicht abzugsf�hig.Schuldzinsen kurzfr.�4Abs4a EStG',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7320 , 'Zinsaufwendungen f. langfr. Verbindlichkeiten     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7326 , 'Zinsen zur Finanzierung des Anlageverm�gen        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7610 , 'Gewerbesteuer                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7650 , 'Sonst. Steuern                                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7680 , 'Grundsteuer                                       ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 7685 , 'Kfz-Steuer                                        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 9000 , 'Saldenvortr�ge Sachkonten                         ',      0 ,     0 , '    0', '      ');
