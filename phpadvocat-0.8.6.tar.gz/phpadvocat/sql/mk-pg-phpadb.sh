psql phpadvocat -f pg-createdb.sql
psql phpadvocat -f kontenrahmen-2007.sql
psql phpadvocat -f mandatory.sql
psql phpadvocat -f demo.sql
