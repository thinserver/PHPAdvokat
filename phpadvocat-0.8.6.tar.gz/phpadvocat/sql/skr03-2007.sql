insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (   15 , 'Konzessionen                                      ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (   27 , 'EDV-Software                                      ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (   90 , 'Gesch�ftsbauten                                   ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  115 , 'Andere Bauten                                     ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  210 , 'Maschinen                                         ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  290 , 'Technische Anlagen u. Maschinen im Bau            ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  299 , 'Anzahlung auf techn.Anlagen u. Maschinen          ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  320 , 'Pkw                                               ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  350 , 'Lkw                                               ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  380 , 'Sonstige Transportmittel                          ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  400 , 'Betriebsausstattung                               ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  410 , 'Gesch�ftsausstattung                              ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  420 , 'B�roeinrichtung                                   ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  440 , 'Werkzeuge                                         ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  480 , 'GWG bis 410 Euro                                  ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  490 , 'Sonst. Betriebs- u. Gesch�ftsausstattung          ',      0 ,  1576 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values (  940 , 'Sonderabschreibungen                              ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1000 , 'Kasse                                             ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1100 , 'Postbank                                          ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1200 , 'Bank                                              ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1360 , 'Geldtransit                                       ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1390 , 'Verrechnungskonto Istversteuerung                 ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1400 , 'Forderungen aus L.u.L                             ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1570 , 'Abziehbare Vorsteuer                              ',     66 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1571 , 'Abziehbare Vorsteuer  7%                          ',     66 ,     0 , '    7', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1572 , 'Abziehbare Vorsteuer  7% innergem. Erwerb         ',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1573 , 'Abziehbare Vorsteuer 16% innergem. Erwerb         ',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1574 , 'Abziehbare Vorsteuer 19% innergem. Erwerb         ',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1575 , 'Abziehbare Vorsteuer 16%                          ',     66 ,     0 , '   16', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1576 , 'Abziehbare Vorsteuer 19%                          ',     66 ,     0 , '   19', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1577 , 'Abziehbare Vorsteuer 19% n.�13b UStG              ',     67 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1584 , 'Abziehb.VSt. a.innerg. Erwerb von KFZ o. UST-ID Nr',     61 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1588 , 'Bezahlte Einfuhrumsatzsteuer                      ',     62 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1590 , 'Durchlaufende Posten                              ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1600 , 'Verbindlichkeiten aus L.uL.                       ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1758 , 'Umsatzst. n. �13 b Abs.2 UStG 16%                 ',     53 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1770 , 'Umsatzsteuer                                      ',     36 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1771 , 'Umsatzsteuer 7%                                   ',      0 ,     0 , '    7', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1772 , 'Umsatzsteuer  7% innergem. Erwerb                 ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1773 , 'Umsatzsteuer 16% innergem. Erwerb                 ',     98 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1774 , 'Umsatzsteuer 19% innergem. Erwerb                 ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1775 , 'Umsatzsteuer 16%                                  ',     36 ,     0 , '   16', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1776 , 'Umsatzsteuer 19%                                  ',      0 ,     0 , '   19', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1778 , 'Umsatzsteuer a.i.Inland steuerpfl.EG-Lfg. 19%     ',      0 ,     0 , '   19', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1780 , 'Umsatzsteuer-Vorauszahlungen                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1781 , 'Umsatzsteuer-Vorauszahlung 1/11                   ',     39 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1782 , 'Umsatzsteuer-Erstattungen                         ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1785 , 'Umsatzsteuer nach �13 UStG                        ',     85 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1786 , 'Umsatzsteuer nach �13b UStG 16%                   ',     85 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1787 , 'Umsatzsteuer nach �13b UStG 19%                   ',     85 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1790 , 'Umsatzsteuer Vorjahr                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1800 , 'Privatentnahmen                                   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1810 , 'Privatsteuern                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1840 , 'Privatspenden                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1880 , 'Privatverbrauch                                   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 1890 , 'Privateinlagen                                    ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2110 , 'Zinsaufwendungen f. kurzfristige Verbindlichkeiten',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2113 , 'Nicht abzugsf. Schuldzinsen �4 Abs 4a langfristig ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2114 , 'Nicht abzugsf. Schuldzinsen �4 Abs 4a kurzfristig ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2120 , 'Zinsaufwendungen f. langfristige Verbindlichkeiten',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2126 , 'Zinsen zur Finanzierung des AV                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2310 , 'Anlagenabg. Sachanlagen - Restbuchwert            ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2340 , 'Einstellg. in SoPo mit R�cklageanteil (stfr.R�ckl)',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2341 , 'Einstellg. in SoPo mit R�cklageanteil (Ansparab.) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2342 , 'Einstellg. in SoPo mit R�cklageanteil(Existenzgr) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2375 , 'Grundsteuer                                       ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2650 , 'Sonstige Zinsen u. �hnliche Ertr�ge               ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2709 , 'Sonstige Ertr�ge 19% Ust.                         ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2733 , 'Ertr�ge a.Aufl�sg.SoPo m.R�ckl.(Existenzgr�nderRL)',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2735 , 'Ertr�ge aus der Aufl. von R�ckstellungen          ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 2739 , 'Ertr�ge a.Aufl�sg.SoPo m.R�cklageA(Ansparabschr)  ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3000 , 'Materialaufwand Roh- Hilfs- Betriebsstoffe        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3090 , 'Energiestoffe                                     ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3100 , 'Fremdleistungen                                   ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3110 , 'Bauleistungen e.i.Inland ans.UN  7% VSt./USt.     ',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3115 , 'Leistung.n.�13b UStG e.i.Ausland ans.UN 7% VSt/USt',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3120 , 'Bauleistungen e.i.Inland ans.UN  19% VSt./USt.    ',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3125 , 'Leistung.n.�13bUStG e.i.Ausland ans.UN 19% VSt/USt',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3130 , 'Bauleistungen e.i.Inland ans.UN o.VSt.Abzug 7% Ust',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3135 , 'Leistung. n.�13b UStG e.i.Ausl.ans.UN o.VSt/7%Ust ',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3140 , 'Bauleistung.e.i.Inland ans.UN o. VSt.Abzug 19% Ust',     84 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3145 , 'Leistung. n.�13b UStG e.i.Ausl.ans.UN o.VSt/19%Ust',     52 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3200 , 'Wareneingang                                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3300 , 'Wareneingang  7% Vorsteuer                        ',      0 ,  1571 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3340 , 'Wareneingang 16% Vorsteuer                        ',      0 ,  1575 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3400 , 'Wareneingang 19% Vorsteuer                        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3420 , 'Innergem. Erwerb  7% VSt. u. USt.                 ',     93 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3425 , 'Innergem. Erwerb 19% VSt. u. USt.                 ',     89 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3430 , 'Innergem. Erwerb ohne VSt/ 7% USt                 ',     93 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3435 , 'Innergem. Erwerb ohne VSt/19% USt                 ',     89 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3440 , 'Innergem.Erwerb Neu-KFZ v.Lief.o.UiD 19% VST/UST  ',     94 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 3550 , 'Steuerfreier innergem. Erwerb                     ',     91 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4000 , 'Materialkosten                                    ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4100 , 'L�hne und Geh�lter                                ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4110 , 'L�hne                                             ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4120 , 'Geh�lter                                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4125 , 'Ehegattengehalt                                   ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4130 , 'Gesetzliche soziale Aufwendungen                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4138 , 'Beitr�ge zur Berufsgenossenschaft                 ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4150 , 'Krankengeldzusch�sse                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4175 , 'Fahrtkostenerstattung                             ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4180 , 'Bedienungsgelder                                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4190 , 'Aushilfsl�hne                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4199 , 'Pauschale Steuer f�r Aushilfen                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4200 , 'Raumkosten                                        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4210 , 'Miete                                             ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4220 , 'Pacht                                             ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4230 , 'Heizung                                           ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4240 , 'Gas, Strom,  Wasser                               ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4250 , 'Reinigung                                         ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4260 , 'Instandhaltung betrieblicher R�ume                ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4280 , 'Sonstige Raumkosten                               ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4288 , 'Aufw.f. h�usl.Arbeitszimmer (abzugsf.Anteil)      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4289 , 'Aufw.f. h�usl.Arbeitszimmer (nicht abzugsf.)      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4320 , 'Gewerbesteuer                                     ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4340 , 'Sonstige Betriebssteuern                          ',      0 ,     0 , '    0', '      ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4360 , 'Versicherungen                                    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4380 , 'Beitr�ge                                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4390 , 'Sonstige Abgaben                                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4500 , 'Kfz-Kosten                                        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4510 , 'Kfz-Steuer                                        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4520 , 'Kfz-Versicherungen                                ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4530 , 'Laufende Kfz-Betriebskosten                       ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4540 , 'Kfz-Reparaturen                                   ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4550 , 'Garagenmieten                                     ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4560 , 'Mautgeb�hren                                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4570 , 'Leasing-Fahrzeugkosten                            ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4580 , 'Sonstige Kfz-Kosten                               ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4600 , 'Werbe- u. Reisekosten                             ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4610 , 'Werbekosten                                       ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4630 , 'Geschenke (abzugsf.)                              ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4635 , 'Geschenke (nicht abzugsf.)                        ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4638 , 'Geschenke ausschlie�l. betrieblich genutzt        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4640 , 'Repr�sentationskosten(abzugsf�hig)                ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4650 , 'Bewirtungskosten (abzugsf�hig)                    ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4651 , 'Sonst.eingeschr. Betriebsausgaben(abzugsf.)       ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4652 , 'Sonst.eingeschr. Betriebsausgab(nicht abz.)       ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4654 , 'Bewirtungskosten(nicht abzugsf�hig)               ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4655 , 'Betriebsausgaben(nicht abzugsf.)                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4660 , 'Reisekosten Arbeitnehmer                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4663 , 'Reisekosten mit Vorsteuerabzug  AN                ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4670 , 'Reisekosten Unternehmer                           ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4673 , 'Reisekosten mit Vorsteuerabzug UN                 ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4678 , 'Fahrten zw. Wohnung u. Arbeitsst�tte( abziehb)    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4679 , 'Fahrten zw. Wohnung u. Arbeitsst�tte(nicht abz.)  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4700 , 'Kosten der Warenabgabe                            ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4710 , 'Verpackungsmaterial                               ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4730 , 'Ausgangsfrachten                                  ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4750 , 'Transportversicherungen                           ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4760 , 'Verkaufsprovisionen                               ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4780 , 'Fremdarbeiten                                     ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4790 , 'Aufwand f�r Gew�hrleistungen                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4800 , 'Reparatur-Instandhaltung masch.Anlagen            ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4805 , 'Reparatur-Instandhaltung Betr.u.Gesch�ftsausst.   ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4806 , 'Wartungskosten f. Hard- u. Software               ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4809 , 'Sonstige Reparaturen und Instandhaltungen         ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4810 , 'Mietleasing                                       ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4822 , 'Abschreibung immaterielle Verm�gensgegenst�nde    ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4824 , 'Abschreibung Gesch�fts- oder Firmenwert           ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4830 , 'Abschreibung Sachanlagen                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4831 , 'Abschreibung auf Geb�ude                          ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4832 , 'Abschreibung auf Kfz                              ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4850 , 'Sonderabschreibungen Sachanlagen                  ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4851 , 'Sond. Abschreib.nach � 7g Abs.1 u.2 EStG(ohne Kfz)',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4852 , 'Sond. Abschreib.nach � 7g Abs.1 u.2 EStG(f�r Kfz) ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4855 , 'Sofortabschreibung GWG                            ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4860 , 'Abschreibung aktivierte GWG                       ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4900 , 'Sonstige betriebliche Aufwendungen                ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4910 , 'Porto                                             ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4920 , 'Telefon                                           ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4925 , 'Telefax                                           ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4930 , 'B�robedarf                                        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4940 , 'Zeitschriften, B�cher                             ',      0 ,  1571 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4945 , 'Fortbildungskosten                                ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4950 , 'Rechts- u. Beratungskosten                        ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4955 , 'Buchf�hrungskosten                                ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4960 , 'Mieten f�r Einrichtungen                          ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4969 , 'Abfallbeseitigungskosten                          ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4970 , 'Nebenkosten des Geldverkehrs                      ',      0 ,     0 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4980 , 'Betriebsbedarf                                    ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 4985 , 'Werkzeuge und Kleinger�te                         ',      0 ,  1576 , '    0', ' Ausg ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8100 , 'Steuerfreie Ums�tze - � 4 Nr. 8 ff UStG           ',     48 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8120 , 'Steuerfreie Ums�tze - � 4 Nr. 2 ff UStG           ',     43 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8125 , 'Steuerfreie innergem. Lieferungen                 ',     41 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8150 , 'Sonstige steuerfreie Ums�tze (Ausfuhr)            ',     43 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8190 , 'Erl�se d.mit Durchschnitts�tzen � 24 UStG verst.  ',     76 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8195 , 'Erl�se gem. � 19 UStG Kleinuntern.                ',      0 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8200 , 'Erl�se                                            ',     35 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8300 , 'Erl�se  7% USt                                    ',     86 ,  1771 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8310 , 'Erl�se a.i.Inland stpfl.EU-Lfg. 7%USt             ',     86 ,  1771 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8315 , 'Erl�se a.i.Inland stpfl.EU-Lfg. 19%USt            ',     81 ,  1778 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8337 , 'Erl�se i.S.� 13b UStG  19%                        ',     60 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8340 , 'Erl�se 16% USt                                    ',     35 ,  1775 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8400 , 'Erl�se 19% USt                                    ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8500 , 'Provisionserl�se                                  ',     35 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8506 , 'Provisionserl�se  7% USt                          ',     86 ,  1771 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8508 , 'Provisionserl�se 19% Ust.                         ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8640 , 'Sonst.Erl�se betriebl.u.regelm.19%                ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8801 , 'Erl�se Anlagenverkauf 19%                         ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8910 , 'Warenentnahme 19% USt                             ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8915 , 'Warenentnahme 7% USt.                             ',     86 ,  1771 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8919 , 'Warenentnahme ohne USt.                           ',     48 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8920 , 'Verwendg.v.Gegenst. 19% USt.                      ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8921 , 'Private Kfz-Nutzung 19% Ust                       ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8922 , 'Private Telefonnutzung 19% USt                    ',     81 ,  1776 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8924 , 'Private Kfz-Nutzung ohne USt                      ',     48 ,     0 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 8930 , 'Verwendg.v.Gegenst. 7% USt.                       ',     86 ,  1771 , '    0', ' Einn ');
insert into phpa_exp_categories (number,description,uva_code,tax_category,taxfactor,in_or_out) 
values ( 9000 , 'Saldenvortr�ge Sachkonten                         ',      0 ,     0 , '    0', '      ');
